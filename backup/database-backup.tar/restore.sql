--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.6
-- Dumped by pg_dump version 14.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "CBMSLAKZODev";
--
-- Name: CBMSLAKZODev; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "CBMSLAKZODev" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_India.1252';


ALTER DATABASE "CBMSLAKZODev" OWNER TO postgres;

\connect "CBMSLAKZODev"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum_ActivityLogs_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_ActivityLogs_status" AS ENUM (
    'Success',
    'Fail'
);


ALTER TYPE public."enum_ActivityLogs_status" OWNER TO postgres;

--
-- Name: enum_Employees_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Employees_category" AS ENUM (
    'Promoter',
    'Employee',
    'Director',
    'Partner'
);


ALTER TYPE public."enum_Employees_category" OWNER TO postgres;

--
-- Name: enum_Employees_security_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Employees_security_type" AS ENUM (
    'Shares',
    'Warrants',
    'Convertible Debentures',
    'Rights',
    'Entitlements'
);


ALTER TYPE public."enum_Employees_security_type" OWNER TO postgres;

--
-- Name: enum_Employees_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Employees_status" AS ENUM (
    'Temp',
    'Active',
    'Update',
    'Release',
    'Deactive'
);


ALTER TYPE public."enum_Employees_status" OWNER TO postgres;

--
-- Name: enum_Relatives_security_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Relatives_security_type" AS ENUM (
    'Shares',
    'Warrants',
    'Convertible Debentures',
    'Rights',
    'Entitlements'
);


ALTER TYPE public."enum_Relatives_security_type" OWNER TO postgres;

--
-- Name: enum_Relatives_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Relatives_status" AS ENUM (
    'Active',
    'Release',
    'Deactive'
);


ALTER TYPE public."enum_Relatives_status" OWNER TO postgres;

--
-- Name: enum_Relatives_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Relatives_type" AS ENUM (
    'Immediate Relative',
    'Material Financial Relationship'
);


ALTER TYPE public."enum_Relatives_type" OWNER TO postgres;

--
-- Name: enum_Requests_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Requests_category" AS ENUM (
    'Promoter',
    'Employee',
    'Director',
    'Partner',
    'Immediate Relative',
    'Material Financial Relationship'
);


ALTER TYPE public."enum_Requests_category" OWNER TO postgres;

--
-- Name: enum_Requests_mode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Requests_mode" AS ENUM (
    'Market',
    'Public',
    'Preferential Offer',
    'Rights',
    'Off Market',
    'ESOP Request',
    'Inter-se Transfer'
);


ALTER TYPE public."enum_Requests_mode" OWNER TO postgres;

--
-- Name: enum_Requests_previous_security_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Requests_previous_security_type" AS ENUM (
    'Shares',
    'Warrants',
    'Convertible Debentures',
    'Rights',
    'Entitlements'
);


ALTER TYPE public."enum_Requests_previous_security_type" OWNER TO postgres;

--
-- Name: enum_Requests_request_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Requests_request_status" AS ENUM (
    'Pending',
    'Approved',
    'Rejected',
    'Expired',
    'Completed'
);


ALTER TYPE public."enum_Requests_request_status" OWNER TO postgres;

--
-- Name: enum_Requests_request_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Requests_request_type" AS ENUM (
    'Purchase',
    'Sell'
);


ALTER TYPE public."enum_Requests_request_type" OWNER TO postgres;

--
-- Name: enum_Requests_security_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Requests_security_type" AS ENUM (
    'Shares',
    'Warrants',
    'Convertible Debentures',
    'Rights',
    'Entitlements'
);


ALTER TYPE public."enum_Requests_security_type" OWNER TO postgres;

--
-- Name: enum_Requests_stock_exchange; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."enum_Requests_stock_exchange" AS ENUM (
    'BSE',
    'NSE'
);


ALTER TYPE public."enum_Requests_stock_exchange" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ActivityLogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ActivityLogs" (
    id integer NOT NULL,
    activity character varying(255) DEFAULT ''::character varying,
    description character varying(255) DEFAULT ''::character varying,
    period character varying(255) DEFAULT ''::character varying,
    done_by text DEFAULT ''::text,
    done_for text DEFAULT ''::text,
    status public."enum_ActivityLogs_status",
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ActivityLogs" OWNER TO postgres;

--
-- Name: ActivityLogs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ActivityLogs_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ActivityLogs_id_seq" OWNER TO postgres;

--
-- Name: ActivityLogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ActivityLogs_id_seq" OWNED BY public."ActivityLogs".id;


--
-- Name: Companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Companies" (
    id integer NOT NULL,
    code character varying(255) DEFAULT ''::character varying,
    name character varying(255) DEFAULT ''::character varying,
    isin character varying(255) DEFAULT ''::character varying,
    cin character varying(255) DEFAULT ''::character varying,
    address text DEFAULT ''::text,
    city character varying(255) DEFAULT ''::character varying,
    state character varying(255) DEFAULT ''::character varying,
    pin character varying(255) DEFAULT ''::character varying,
    phone character varying(255) DEFAULT ''::character varying,
    fax character varying(255) DEFAULT ''::character varying,
    email character varying(255) DEFAULT ''::character varying,
    total_capital double precision DEFAULT '0'::double precision,
    share_value double precision DEFAULT '0'::double precision,
    contact_person character varying(255) DEFAULT ''::character varying,
    window_close_from timestamp without time zone,
    window_close_to timestamp without time zone,
    purpose text DEFAULT ''::text,
    website text DEFAULT ''::text,
    meta_tag text DEFAULT ''::text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Companies" OWNER TO postgres;

--
-- Name: Companies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Companies_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Companies_id_seq" OWNER TO postgres;

--
-- Name: Companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Companies_id_seq" OWNED BY public."Companies".id;


--
-- Name: Conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Conversations" (
    id integer NOT NULL,
    subject text DEFAULT ''::text,
    information text DEFAULT ''::text,
    is_active boolean DEFAULT true,
    status character varying(255) DEFAULT ''::character varying,
    "attachmentUrl" character varying(255) DEFAULT ''::character varying,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    upsi_id integer,
    sender_id character varying(255),
    receiver_id character varying(255)
);


ALTER TABLE public."Conversations" OWNER TO postgres;

--
-- Name: Conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Conversations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Conversations_id_seq" OWNER TO postgres;

--
-- Name: Conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Conversations_id_seq" OWNED BY public."Conversations".id;


--
-- Name: Employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employees" (
    id integer NOT NULL,
    pan character varying(255) NOT NULL,
    other_identifier_type character varying(255) DEFAULT ''::character varying,
    other_identifier_no character varying(255) DEFAULT ''::character varying,
    emp_code character varying(255) DEFAULT ''::character varying,
    name character varying(255) DEFAULT ''::character varying,
    email character varying(255) DEFAULT ''::character varying,
    password character varying(255) DEFAULT ''::character varying,
    category public."enum_Employees_category" DEFAULT 'Employee'::public."enum_Employees_category",
    designation character varying(255) DEFAULT ''::character varying,
    phone character varying(255) DEFAULT ''::character varying,
    address text DEFAULT ''::text,
    total_share double precision DEFAULT '0'::double precision,
    security_type public."enum_Employees_security_type" DEFAULT 'Shares'::public."enum_Employees_security_type",
    last_benpos_date timestamp with time zone,
    date_of_appointment_as_insider timestamp with time zone,
    last_institute text DEFAULT ''::text,
    last_employer text DEFAULT ''::text,
    is_active boolean DEFAULT true,
    is_compliance boolean DEFAULT false,
    photo character varying(255),
    status public."enum_Employees_status" DEFAULT 'Active'::public."enum_Employees_status",
    release_date timestamp with time zone,
    temp_info jsonb,
    "refreshAccessToken" text DEFAULT ''::text,
    "registrationToken" character varying(255) DEFAULT ''::character varying,
    type character varying(255) DEFAULT 'DP'::character varying,
    "canEdit" boolean DEFAULT false,
    upsi boolean DEFAULT false,
    reason text DEFAULT ''::text,
    "firstLogin" boolean DEFAULT false,
    "isManagement" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    company_id integer
);


ALTER TABLE public."Employees" OWNER TO postgres;

--
-- Name: Employees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Employees_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Employees_id_seq" OWNER TO postgres;

--
-- Name: Employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Employees_id_seq" OWNED BY public."Employees".id;


--
-- Name: Folios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Folios" (
    id integer NOT NULL,
    folio character varying(255) NOT NULL,
    current_share double precision DEFAULT '0'::double precision,
    is_active boolean DEFAULT true,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    emp_pan character varying(255),
    emp_relative_pan character varying(255)
);


ALTER TABLE public."Folios" OWNER TO postgres;

--
-- Name: Folios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Folios_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Folios_id_seq" OWNER TO postgres;

--
-- Name: Folios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Folios_id_seq" OWNED BY public."Folios".id;


--
-- Name: Relatives; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Relatives" (
    id integer NOT NULL,
    emp_sub_code character varying(255) DEFAULT ''::character varying,
    pan character varying(255) DEFAULT ''::character varying NOT NULL,
    email character varying(255) DEFAULT ''::character varying,
    phone character varying(255) DEFAULT ''::character varying,
    name character varying(255) DEFAULT ''::character varying,
    address text DEFAULT ''::text,
    type public."enum_Relatives_type" DEFAULT 'Immediate Relative'::public."enum_Relatives_type",
    relation character varying(255) DEFAULT ''::character varying,
    total_share double precision DEFAULT '0'::double precision,
    security_type public."enum_Relatives_security_type" DEFAULT 'Shares'::public."enum_Relatives_security_type",
    last_benpos_date timestamp without time zone,
    release_date timestamp without time zone,
    last_institute text DEFAULT ''::text,
    last_employer text DEFAULT ''::text,
    other_identifier_type character varying(255) DEFAULT ''::character varying,
    other_identifier_no character varying(255) DEFAULT ''::character varying,
    status public."enum_Relatives_status" DEFAULT 'Active'::public."enum_Relatives_status",
    is_active boolean DEFAULT true,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    emp_pan character varying(255)
);


ALTER TABLE public."Relatives" OWNER TO postgres;

--
-- Name: Relatives_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Relatives_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Relatives_id_seq" OWNER TO postgres;

--
-- Name: Relatives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Relatives_id_seq" OWNED BY public."Relatives".id;


--
-- Name: Requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Requests" (
    id integer NOT NULL,
    category public."enum_Requests_category" DEFAULT 'Employee'::public."enum_Requests_category",
    security_type public."enum_Requests_security_type" DEFAULT 'Shares'::public."enum_Requests_security_type",
    mode public."enum_Requests_mode" DEFAULT 'Market'::public."enum_Requests_mode",
    request_type public."enum_Requests_request_type" DEFAULT 'Purchase'::public."enum_Requests_request_type",
    date_requested_from timestamp without time zone,
    date_requested_to timestamp without time zone,
    request_quantity double precision DEFAULT '0'::double precision,
    proposed_price double precision DEFAULT '0'::double precision,
    market_price double precision DEFAULT '0'::double precision,
    previous_total_share double precision DEFAULT '0'::double precision,
    previous_security_type public."enum_Requests_previous_security_type" DEFAULT 'Shares'::public."enum_Requests_previous_security_type",
    request_status public."enum_Requests_request_status" DEFAULT 'Pending'::public."enum_Requests_request_status",
    request_date timestamp without time zone,
    approval_date timestamp without time zone,
    transaction_date timestamp without time zone,
    transaction_quantity double precision DEFAULT '0'::double precision,
    pan character varying(255) DEFAULT ''::character varying,
    transaction_price double precision DEFAULT '0'::double precision,
    stock_exchange public."enum_Requests_stock_exchange",
    trans_folio character varying(255) DEFAULT ''::character varying,
    reason text DEFAULT ''::text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    request_folio character varying(255),
    data_id integer
);


ALTER TABLE public."Requests" OWNER TO postgres;

--
-- Name: Requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Requests_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Requests_id_seq" OWNER TO postgres;

--
-- Name: Requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Requests_id_seq" OWNED BY public."Requests".id;


--
-- Name: Templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Templates" (
    id integer NOT NULL,
    name character varying(255) DEFAULT ''::character varying,
    type character varying(255) DEFAULT ''::character varying,
    subject text DEFAULT ''::text,
    body text DEFAULT ''::text,
    variables text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Templates" OWNER TO postgres;

--
-- Name: Templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Templates_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Templates_id_seq" OWNER TO postgres;

--
-- Name: Templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Templates_id_seq" OWNED BY public."Templates".id;


--
-- Name: UPSILogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UPSILogs" (
    id integer NOT NULL,
    shared_by text DEFAULT ''::text,
    shared_with text DEFAULT ''::text,
    subject text DEFAULT ''::text,
    information text DEFAULT ''::text,
    sender_id character varying(255) DEFAULT NULL::character varying,
    receiver_id character varying(255) DEFAULT NULL::character varying,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."UPSILogs" OWNER TO postgres;

--
-- Name: UPSILogs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UPSILogs_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UPSILogs_id_seq" OWNER TO postgres;

--
-- Name: UPSILogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UPSILogs_id_seq" OWNED BY public."UPSILogs".id;


--
-- Name: UploadDatas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UploadDatas" (
    id integer NOT NULL,
    previous_share double precision DEFAULT '0'::double precision,
    current_share double precision DEFAULT '0'::double precision,
    pan character varying(255) DEFAULT ''::character varying,
    previous_total_share double precision DEFAULT '0'::double precision,
    total_share double precision DEFAULT '0'::double precision,
    current_benpos_date timestamp without time zone,
    last_share_change_date timestamp without time zone,
    is_share_changed boolean DEFAULT false,
    is_valid boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    transaction_folio character varying(255)
);


ALTER TABLE public."UploadDatas" OWNER TO postgres;

--
-- Name: UploadDatas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UploadDatas_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UploadDatas_id_seq" OWNER TO postgres;

--
-- Name: UploadDatas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UploadDatas_id_seq" OWNED BY public."UploadDatas".id;


--
-- Name: ActivityLogs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActivityLogs" ALTER COLUMN id SET DEFAULT nextval('public."ActivityLogs_id_seq"'::regclass);


--
-- Name: Companies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Companies" ALTER COLUMN id SET DEFAULT nextval('public."Companies_id_seq"'::regclass);


--
-- Name: Conversations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversations" ALTER COLUMN id SET DEFAULT nextval('public."Conversations_id_seq"'::regclass);


--
-- Name: Employees id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employees" ALTER COLUMN id SET DEFAULT nextval('public."Employees_id_seq"'::regclass);


--
-- Name: Folios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Folios" ALTER COLUMN id SET DEFAULT nextval('public."Folios_id_seq"'::regclass);


--
-- Name: Relatives id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Relatives" ALTER COLUMN id SET DEFAULT nextval('public."Relatives_id_seq"'::regclass);


--
-- Name: Requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Requests" ALTER COLUMN id SET DEFAULT nextval('public."Requests_id_seq"'::regclass);


--
-- Name: Templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Templates" ALTER COLUMN id SET DEFAULT nextval('public."Templates_id_seq"'::regclass);


--
-- Name: UPSILogs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UPSILogs" ALTER COLUMN id SET DEFAULT nextval('public."UPSILogs_id_seq"'::regclass);


--
-- Name: UploadDatas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UploadDatas" ALTER COLUMN id SET DEFAULT nextval('public."UploadDatas_id_seq"'::regclass);


--
-- Data for Name: ActivityLogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ActivityLogs" (id, activity, description, period, done_by, done_for, status, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."ActivityLogs" (id, activity, description, period, done_by, done_for, status, "createdAt", "updatedAt") FROM '$$PATH$$/3533.dat';

--
-- Data for Name: Companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Companies" (id, code, name, isin, cin, address, city, state, pin, phone, fax, email, total_capital, share_value, contact_person, window_close_from, window_close_to, purpose, website, meta_tag, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Companies" (id, code, name, isin, cin, address, city, state, pin, phone, fax, email, total_capital, share_value, contact_person, window_close_from, window_close_to, purpose, website, meta_tag, "createdAt", "updatedAt") FROM '$$PATH$$/3535.dat';

--
-- Data for Name: Conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Conversations" (id, subject, information, is_active, status, "attachmentUrl", "createdAt", "updatedAt", upsi_id, sender_id, receiver_id) FROM stdin;
\.
COPY public."Conversations" (id, subject, information, is_active, status, "attachmentUrl", "createdAt", "updatedAt", upsi_id, sender_id, receiver_id) FROM '$$PATH$$/3541.dat';

--
-- Data for Name: Employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employees" (id, pan, other_identifier_type, other_identifier_no, emp_code, name, email, password, category, designation, phone, address, total_share, security_type, last_benpos_date, date_of_appointment_as_insider, last_institute, last_employer, is_active, is_compliance, photo, status, release_date, temp_info, "refreshAccessToken", "registrationToken", type, "canEdit", upsi, reason, "firstLogin", "isManagement", "createdAt", "updatedAt", company_id) FROM stdin;
\.
COPY public."Employees" (id, pan, other_identifier_type, other_identifier_no, emp_code, name, email, password, category, designation, phone, address, total_share, security_type, last_benpos_date, date_of_appointment_as_insider, last_institute, last_employer, is_active, is_compliance, photo, status, release_date, temp_info, "refreshAccessToken", "registrationToken", type, "canEdit", upsi, reason, "firstLogin", "isManagement", "createdAt", "updatedAt", company_id) FROM '$$PATH$$/3539.dat';

--
-- Data for Name: Folios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Folios" (id, folio, current_share, is_active, "createdAt", "updatedAt", emp_pan, emp_relative_pan) FROM stdin;
\.
COPY public."Folios" (id, folio, current_share, is_active, "createdAt", "updatedAt", emp_pan, emp_relative_pan) FROM '$$PATH$$/3545.dat';

--
-- Data for Name: Relatives; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Relatives" (id, emp_sub_code, pan, email, phone, name, address, type, relation, total_share, security_type, last_benpos_date, release_date, last_institute, last_employer, other_identifier_type, other_identifier_no, status, is_active, "createdAt", "updatedAt", emp_pan) FROM stdin;
\.
COPY public."Relatives" (id, emp_sub_code, pan, email, phone, name, address, type, relation, total_share, security_type, last_benpos_date, release_date, last_institute, last_employer, other_identifier_type, other_identifier_no, status, is_active, "createdAt", "updatedAt", emp_pan) FROM '$$PATH$$/3543.dat';

--
-- Data for Name: Requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Requests" (id, category, security_type, mode, request_type, date_requested_from, date_requested_to, request_quantity, proposed_price, market_price, previous_total_share, previous_security_type, request_status, request_date, approval_date, transaction_date, transaction_quantity, pan, transaction_price, stock_exchange, trans_folio, reason, "createdAt", "updatedAt", request_folio, data_id) FROM stdin;
\.
COPY public."Requests" (id, category, security_type, mode, request_type, date_requested_from, date_requested_to, request_quantity, proposed_price, market_price, previous_total_share, previous_security_type, request_status, request_date, approval_date, transaction_date, transaction_quantity, pan, transaction_price, stock_exchange, trans_folio, reason, "createdAt", "updatedAt", request_folio, data_id) FROM '$$PATH$$/3549.dat';

--
-- Data for Name: Templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Templates" (id, name, type, subject, body, variables, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Templates" (id, name, type, subject, body, variables, "createdAt", "updatedAt") FROM '$$PATH$$/3551.dat';

--
-- Data for Name: UPSILogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UPSILogs" (id, shared_by, shared_with, subject, information, sender_id, receiver_id, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."UPSILogs" (id, shared_by, shared_with, subject, information, sender_id, receiver_id, "createdAt", "updatedAt") FROM '$$PATH$$/3537.dat';

--
-- Data for Name: UploadDatas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UploadDatas" (id, previous_share, current_share, pan, previous_total_share, total_share, current_benpos_date, last_share_change_date, is_share_changed, is_valid, "createdAt", "updatedAt", transaction_folio) FROM stdin;
\.
COPY public."UploadDatas" (id, previous_share, current_share, pan, previous_total_share, total_share, current_benpos_date, last_share_change_date, is_share_changed, is_valid, "createdAt", "updatedAt", transaction_folio) FROM '$$PATH$$/3547.dat';

--
-- Name: ActivityLogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ActivityLogs_id_seq"', 1, false);


--
-- Name: Companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Companies_id_seq"', 1, true);


--
-- Name: Conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Conversations_id_seq"', 1, false);


--
-- Name: Employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Employees_id_seq"', 2, true);


--
-- Name: Folios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Folios_id_seq"', 1, false);


--
-- Name: Relatives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Relatives_id_seq"', 1, false);


--
-- Name: Requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Requests_id_seq"', 1, false);


--
-- Name: Templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Templates_id_seq"', 12, true);


--
-- Name: UPSILogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UPSILogs_id_seq"', 1, false);


--
-- Name: UploadDatas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UploadDatas_id_seq"', 1, false);


--
-- Name: ActivityLogs ActivityLogs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActivityLogs"
    ADD CONSTRAINT "ActivityLogs_pkey" PRIMARY KEY (id);


--
-- Name: Companies Companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_pkey" PRIMARY KEY (id);


--
-- Name: Conversations Conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversations"
    ADD CONSTRAINT "Conversations_pkey" PRIMARY KEY (id);


--
-- Name: Employees Employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employees"
    ADD CONSTRAINT "Employees_pkey" PRIMARY KEY (pan);


--
-- Name: Folios Folios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Folios"
    ADD CONSTRAINT "Folios_pkey" PRIMARY KEY (folio);


--
-- Name: Relatives Relatives_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Relatives"
    ADD CONSTRAINT "Relatives_pkey" PRIMARY KEY (pan);


--
-- Name: Requests Requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Requests"
    ADD CONSTRAINT "Requests_pkey" PRIMARY KEY (id);


--
-- Name: Templates Templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Templates"
    ADD CONSTRAINT "Templates_pkey" PRIMARY KEY (id);


--
-- Name: UPSILogs UPSILogs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UPSILogs"
    ADD CONSTRAINT "UPSILogs_pkey" PRIMARY KEY (id);


--
-- Name: UploadDatas UploadDatas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UploadDatas"
    ADD CONSTRAINT "UploadDatas_pkey" PRIMARY KEY (id);


--
-- Name: Conversations Conversations_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversations"
    ADD CONSTRAINT "Conversations_receiver_id_fkey" FOREIGN KEY (receiver_id) REFERENCES public."Employees"(pan) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Conversations Conversations_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversations"
    ADD CONSTRAINT "Conversations_sender_id_fkey" FOREIGN KEY (sender_id) REFERENCES public."Employees"(pan) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Conversations Conversations_upsi_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversations"
    ADD CONSTRAINT "Conversations_upsi_id_fkey" FOREIGN KEY (upsi_id) REFERENCES public."UPSILogs"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Employees Employees_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employees"
    ADD CONSTRAINT "Employees_company_id_fkey" FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Folios Folios_emp_pan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Folios"
    ADD CONSTRAINT "Folios_emp_pan_fkey" FOREIGN KEY (emp_pan) REFERENCES public."Employees"(pan) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Folios Folios_emp_relative_pan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Folios"
    ADD CONSTRAINT "Folios_emp_relative_pan_fkey" FOREIGN KEY (emp_relative_pan) REFERENCES public."Relatives"(pan) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Relatives Relatives_emp_pan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Relatives"
    ADD CONSTRAINT "Relatives_emp_pan_fkey" FOREIGN KEY (emp_pan) REFERENCES public."Employees"(pan) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Requests Requests_data_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Requests"
    ADD CONSTRAINT "Requests_data_id_fkey" FOREIGN KEY (data_id) REFERENCES public."UploadDatas"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Requests Requests_request_folio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Requests"
    ADD CONSTRAINT "Requests_request_folio_fkey" FOREIGN KEY (request_folio) REFERENCES public."Folios"(folio) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UploadDatas UploadDatas_transaction_folio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UploadDatas"
    ADD CONSTRAINT "UploadDatas_transaction_folio_fkey" FOREIGN KEY (transaction_folio) REFERENCES public."Folios"(folio) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

